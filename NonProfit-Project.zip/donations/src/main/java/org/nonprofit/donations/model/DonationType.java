package org.nonprofit.donations.model;

//import javax.xml.bind.annotation.XmlRootElement;

//@XmlRootElement
public class DonationType {

	public int Id;
	public String DonationType;
	public String Description;

	public DonationType() {}
	
	public DonationType(int id, String donationType, String description) {
		Id = id;
		DonationType = donationType;
		Description = description;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getDonationType() {
		return DonationType;
	}
	public void setDonationType(String donationType) {
		DonationType = donationType;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
}
