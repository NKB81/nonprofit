package org.nonprofit.donations.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.nonprofit.donations.model.Donation;
public class DonationService {

	public List<Donation> getAllDonations()throws ClassNotFoundException, SQLException{
		try {
			DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
	        Connection conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=NonProfit;integratedSecurity=true");
			Statement stmt = conn.createStatement();
			String sql = "Select * from Donations";
			ResultSet rs = stmt.executeQuery(sql);
			
			List<Donation> donationList = new ArrayList<>();
			while(rs.next())
			{
				Donation dt = new Donation(rs.getInt("Id"), rs.getString("DonorName"), rs.getString("DonorEmail"), rs.getString("DonorPhone"), rs.getString("DonationType"), rs.getInt("DonationAmount"), rs.getString("PickUpAddress"), rs.getString("PickUpDate"), rs.getString("PickUpTime"), rs.getString("Status"), rs.getString("TrackingId"));
				donationList.add(dt);
			}
			 conn.close();
			return donationList;
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return null;
		}
	}
	
	public String addDonationType(Donation dt)throws ClassNotFoundException, SQLException{
		try {
			DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
	        Connection conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=NonProfit;integratedSecurity=true");
			
			String query = " insert into Donations(DonorName, DonorEmail, DonorPhone, DonationType, DonationAmount, PickUpAddress, PickUpDate, PickUpTime, Status, TrackingId)"
		        + " values (?, ?,?, ?,?, ?,?, ?,?, ?)";

				UUID uuid = UUID.randomUUID();
		        String randomUUIDString = uuid.toString();
		      // create the sql insert preparedstatement
		      PreparedStatement preparedStmt = conn.prepareStatement(query);
		      preparedStmt.setString (1, dt.getDonorName());
		      preparedStmt.setString (2, dt.getDonorEmail());
		      preparedStmt.setString (3, dt.getDonorPhone());
		      preparedStmt.setString (4, dt.getDonationType());
		      preparedStmt.setInt (5, dt.getDonationAmount());
		      preparedStmt.setString (6, dt.getPickUpAddress());
		      preparedStmt.setString (7, dt.getPickUpDate());
		      preparedStmt.setString (8, dt.getPickUpTime());
		      preparedStmt.setString (9, dt.getStatus());
		      preparedStmt.setString (10, randomUUIDString);

		      // execute the preparedstatement
		      preparedStmt.execute();
		     
		      conn.close();
			return "Entry Successful!";
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return null;
		}
	}
}

