package org.nonprofit.donations;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.nonprofit.donations.model.DonationType;
import org.nonprofit.donations.service.DonationTypeService;

@Path("/donationtypes")
public class DonationTypes {

	public DonationTypeService ds = new DonationTypeService();
	@GET
	@Produces(MediaType.TEXT_HTML)
	public String getDonationTypes() throws ClassNotFoundException, SQLException{
		List<DonationType> a1 = new ArrayList<>(); 
		a1 = ds.getAllDonationTypes();
		String htmlResponse = "<html><table><tr><th>Id</th><th>Donation Type</th><th>Description</th></tr>";
		
		for(int i = 0; i<a1.size(); i++)
		{
			htmlResponse += "<tr><td>"+a1.get(i).getId()+"</td><td>"+a1.get(i).getDonationType()+"</td><td>"+a1.get(i).getDescription()+"</td></tr>";
		}
		htmlResponse += "</table></html>";
		return htmlResponse;
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_HTML)
	public String addDonationType(DonationType donationType) throws ClassNotFoundException, SQLException{
		//ds.addDonationType(donationType);
		return ds.addDonationType(donationType);
				//htmlResponse;
				//ds.getAllDonationTypes();
	}
}
