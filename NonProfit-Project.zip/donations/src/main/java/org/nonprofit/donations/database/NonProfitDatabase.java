package org.nonprofit.donations.database;

import java.sql.*;


public class NonProfitDatabase {

	public void dbConnect(String db_connect_string,
            String db_userid,
            String db_password)
   {
      try {
         Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
         Connection conn = DriverManager.getConnection(db_connect_string,
                  db_userid, db_password);
         System.out.println("connected");
         Statement statement = conn.createStatement();
         String queryString = "select DonationType from NonProfit..DonationType";
         ResultSet rs = statement.executeQuery(queryString);
         while (rs.next()) {
            System.out.println(rs.getString(1));
         }
      } catch (Exception e) {
         e.printStackTrace();
      }
   }
	
   public static void main(String[] args)
   {
	   NonProfitDatabase connServer = new NonProfitDatabase();
      connServer.dbConnect("jdbc:sqlserver://HP", "nitin",
               "pinku");
   }
}
