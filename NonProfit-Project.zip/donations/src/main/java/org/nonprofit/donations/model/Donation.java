package org.nonprofit.donations.model;

public class Donation {

	public int Id;
	public String DonorName;
	public String DonorEmail;
	public String DonorPhone;
	public String DonationType;
	public int DonationAmount;
	public String PickUpAddress;
	public String PickUpDate;
	public String PickUpTime;
	public String Status;
	public String TrackingId;
	
	public Donation() {}
	
	public Donation(int id, String donName, String donEmail, String donPhn, String donType, int donAmt, String puAdd, String puDate, String puTime, String status, String trackId)
	{
		Id = id;
		DonorName = donName;
		DonorEmail = donEmail;
		DonorPhone = donPhn;
		DonationType = donType;
		DonationAmount = donAmt;
		PickUpAddress = puAdd;
		PickUpDate = puDate;
		PickUpTime = puTime;
		Status = status;
		TrackingId = trackId;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getDonorName() {
		return DonorName;
	}

	public void setDonorName(String donorName) {
		DonorName = donorName;
	}

	public String getDonorEmail() {
		return DonorEmail;
	}

	public void setDonorEmail(String donorEmail) {
		DonorEmail = donorEmail;
	}

	public String getDonorPhone() {
		return DonorPhone;
	}

	public void setDonorPhone(String donorPhone) {
		DonorPhone = donorPhone;
	}

	public String getDonationType() {
		return DonationType;
	}

	public void setDonationType(String donationType) {
		DonationType = donationType;
	}

	public int getDonationAmount() {
		return DonationAmount;
	}

	public void setDonationAmount(int donationAmount) {
		DonationAmount = donationAmount;
	}

	public String getPickUpAddress() {
		return PickUpAddress;
	}

	public void setPickUpAddress(String pickUpAddress) {
		PickUpAddress = pickUpAddress;
	}

	public String getPickUpDate() {
		return PickUpDate;
	}

	public void setPickUpDate(String pickUpDate) {
		PickUpDate = pickUpDate;
	}

	public String getPickUpTime() {
		return PickUpTime;
	}

	public void setPickUpTime(String pickUpTime) {
		PickUpTime = pickUpTime;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getTrackingId() {
		return TrackingId;
	}

	public void setTrackingId(String trackingId) {
		TrackingId = trackingId;
	}
}
