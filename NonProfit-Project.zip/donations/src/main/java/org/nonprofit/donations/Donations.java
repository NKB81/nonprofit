package org.nonprofit.donations;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.nonprofit.donations.model.Donation;
import org.nonprofit.donations.service.DonationService;

@Path("/donations")
public class Donations {

	public DonationService ds = new DonationService();
	@GET
	@Produces(MediaType.TEXT_HTML)
	public String getDonationTypes() throws ClassNotFoundException, SQLException{
		List<Donation> a1 = new ArrayList<>(); 
		a1 = ds.getAllDonations();
		String htmlResponse = "<html><table><tr><th>Donor Name</th>"
					+"<th>Donor Email</th><th>Donor Phone</th>"
					+"<th>Donation Type</th><th>Donation Amount/Quantity</th>"
					+"<th>Pick Up Address</th><th>Pick Up Date</th><th>Pick Up Time</th>"
					+"<th>Donation Status</th><th>Tracking Id</th>"
					+"</tr>";
		
		for(int i = 0; i<a1.size(); i++)
		{
			htmlResponse += "<tr>"
					+"<td>"+a1.get(i).getDonorName()+"</td>"
					+"<td>"+a1.get(i).getDonorEmail()+"</td>"
					+"<td>"+a1.get(i).getDonorPhone()+"</td>"
					+"<td>"+a1.get(i).getDonationType()+"</td>"
					+"<td>"+a1.get(i).getDonationAmount()+"</td>"
					+"<td>"+a1.get(i).getPickUpAddress()+"</td>"
					+"<td>"+a1.get(i).getPickUpDate()+"</td>"
					+"<td>"+a1.get(i).getPickUpTime()+"</td>"
					+"<td>"+a1.get(i).getStatus()+"</td>"
					+"<td>"+a1.get(i).getTrackingId()+"</td></tr>";
		}
		htmlResponse += "</table></html>";
		return htmlResponse;
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_HTML)
	public String addDonation(Donation donation) throws ClassNotFoundException, SQLException{
		//ds.addDonationType(donationType);
		return ds.addDonationType(donation);
				//htmlResponse;
				//ds.getAllDonationTypes();
	}
}

