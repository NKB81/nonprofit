package org.nonprofit.donations.service;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.nonprofit.donations.model.DonationType;
public class DonationTypeService {

	public List<DonationType> getAllDonationTypes()throws ClassNotFoundException, SQLException{
		try {
			DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
	        Connection conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=NonProfit;integratedSecurity=true");
			Statement stmt = conn.createStatement();
			String sql = "Select * from DonationType";
			ResultSet rs = stmt.executeQuery(sql);
			
			List<DonationType> donationTypeList = new ArrayList<>();
			while(rs.next())
			{
				DonationType dt = new DonationType(rs.getInt("Id"), rs.getString("DonationType"), rs.getString("Description"));
				donationTypeList.add(dt);
			}
			 conn.close();
			return donationTypeList;
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return null;
		}
	}
	
	public String addDonationType(DonationType dt)throws ClassNotFoundException, SQLException{
		try {
			DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
	        Connection conn = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=NonProfit;integratedSecurity=true");
			
			String query = " insert into DonationType(DonationType, Description)"
		        + " values (?, ?)";

		      // create the sql insert preparedstatement
		      PreparedStatement preparedStmt = conn.prepareStatement(query);
		      preparedStmt.setString (1, dt.getDonationType());
		      preparedStmt.setString (2, dt.getDescription());

		      // execute the preparedstatement
		      preparedStmt.execute();
		     
		      conn.close();
			return "Entry Successful!";
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return null;
		}
	}
}
